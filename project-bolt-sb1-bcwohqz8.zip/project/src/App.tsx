import React, { useState } from 'react';
import { 
  Calendar, 
  User, 
  BarChart3, 
  TrendingUp, 
  Award, 
  Target, 
  Users, 
  Clock, 
  BookOpen, 
  Star,
  Download,
  Edit,
  Save,
  X,
  FileText,
  CheckCircle,
  AlertCircle,
  Info,
  MessageSquare,
  ThumbsUp,
  ThumbsDown,
  PenTool
} from 'lucide-react';

interface ReportData {
  reportTitle: string;
  weekStart: string;
  weekEnd: string;
  preparedBy: string;
  preparedDate: string;
  organization: string;
  department: string;
}

interface EmployeeData {
  name: string;
  position: string;
  evaluations: number;
  rating: number;
  strengths: string;
  negativeNotes: string;
}

function App() {
  const [isEditing, setIsEditing] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [reportData, setReportData] = useState<ReportData>({
    reportTitle: 'تقرير تقييم أداء الموظفين الأسبوعي',
    weekStart: '2025-06-29',
    weekEnd: '2025-07-03',
    preparedBy: 'نايف الشهري',
    preparedDate: '2025-07-04',
    organization: 'مدرسة شمال جدة لتعليم قيادة السيارات',
    department: 'الموارد البشرية / إدارة الجودة'
  });

  const [employeesData, setEmployeesData] = useState<EmployeeData[]>([
    {
      name: 'محمد العصيمي',
      position: 'مدرب قيادة',
      evaluations: 3,
      rating: 4.7,
      strengths: 'الالتزام بالمواعيد، أسلوب الشرح',
      negativeNotes: 'ملاحظة واحدة حول التأخير'
    },
    {
      name: 'عبدالله الغامدي',
      position: 'مدرب قيادة',
      evaluations: 2,
      rating: 4.3,
      strengths: 'اللباقة وسرعة الاستجابة',
      negativeNotes: 'ملاحظات عن تأخير المواعيد'
    },
    {
      name: 'ابراهيم السلمي',
      position: 'مدرب قيادة',
      evaluations: 2,
      rating: 3.9,
      strengths: 'أفضل مدرب معي، أسلوب الشرح',
      negativeNotes: 'ضعف في التنظيم والألفاظ'
    },
    {
      name: 'عبدالرحمن القرني',
      position: 'مدرب قيادة',
      evaluations: 1,
      rating: 4.5,
      strengths: 'الاستقبال الممتاز والتعامل الراقي',
      negativeNotes: 'لا توجد ملاحظات سلبية'
    }
  ]);

  const handleSave = () => {
    setIsEditing(false);
  };

  const handleExport = (format: string) => {
    console.log(`Exporting as ${format}`);
    setShowExportModal(false);
  };

  const updateReportData = (field: keyof ReportData, value: string) => {
    setReportData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const updateEmployeeData = (index: number, field: keyof EmployeeData, value: string | number) => {
    setEmployeesData(prev => prev.map((employee, i) => 
      i === index ? { ...employee, [field]: value } : employee
    ));
  };

  const averageRating = employeesData.reduce((sum, emp) => sum + emp.rating, 0) / employeesData.length;
  const totalEvaluations = employeesData.reduce((sum, emp) => sum + emp.evaluations, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4" dir="rtl">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center space-x-4 space-x-reverse">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-3 rounded-xl">
                <BarChart3 className="h-8 w-8 text-white" />
              </div>
              <div>
                {isEditing ? (
                  <input
                    type="text"
                    value={reportData.reportTitle}
                    onChange={(e) => updateReportData('reportTitle', e.target.value)}
                    className="text-2xl font-bold text-gray-900 bg-transparent border-b-2 border-blue-500 focus:outline-none"
                  />
                ) : (
                  <h1 className="text-2xl font-bold text-gray-900">{reportData.reportTitle}</h1>
                )}
                <div className="mt-2 space-y-1">
                  <p className="text-sm text-gray-600">الجهة: {reportData.organization}</p>
                  <p className="text-sm text-gray-600">القسم: {reportData.department}</p>
                  <p className="text-sm text-gray-600">التاريخ: {reportData.preparedDate}</p>
                </div>
              </div>
            </div>
            
            <div className="flex space-x-3 space-x-reverse">
              {isEditing ? (
                <>
                  <button
                    onClick={handleSave}
                    className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-xl flex items-center space-x-2 space-x-reverse transition-all duration-200 shadow-lg hover:shadow-xl"
                  >
                    <Save className="h-4 w-4" />
                    <span>حفظ</span>
                  </button>
                  <button
                    onClick={() => setIsEditing(false)}
                    className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-xl flex items-center space-x-2 space-x-reverse transition-all duration-200"
                  >
                    <X className="h-4 w-4" />
                    <span>إلغاء</span>
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => setIsEditing(true)}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl flex items-center space-x-2 space-x-reverse transition-all duration-200 shadow-lg hover:shadow-xl"
                  >
                    <Edit className="h-4 w-4" />
                    <span>تعديل</span>
                  </button>
                  <button
                    onClick={() => setShowExportModal(true)}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl flex items-center space-x-2 space-x-reverse transition-all duration-200 shadow-lg hover:shadow-xl"
                  >
                    <Download className="h-4 w-4" />
                    <span>تصدير</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Report Period */}
          <div className="bg-blue-50 rounded-xl p-4">
            <div className="flex items-center space-x-3 space-x-reverse mb-2">
              <Target className="h-5 w-5 text-blue-600" />
              <h3 className="font-semibold text-blue-800">الهدف من التقرير</h3>
            </div>
            <p className="text-sm text-blue-700 leading-relaxed">
              يهدف هذا التقرير إلى تقييم وتحليل أداء الموظفين خلال الفترة من {reportData.weekStart} إلى {reportData.weekEnd}، بناءً على تقييمات العملاء واستبيانات الأداء، وذلك للتعرف على جودة الخدمات المقدمة وتحديد فرص التحسين.
            </p>
          </div>
        </div>

        {/* Summary Section */}
        <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
          <div className="flex items-center space-x-3 space-x-reverse mb-4">
            <FileText className="h-6 w-6 text-blue-600" />
            <h2 className="text-xl font-bold text-gray-900">أولاً: ملخص عام</h2>
          </div>
          <p className="text-gray-700 leading-relaxed">
            تم خلال هذا الأسبوع جمع وتحليل نتائج استبيانات تقييم الأداء للموظفين من واقع آراء العملاء بعد تقديم الخدمة. يوضح التقرير مستوى الرضا العام، ويبرز نقاط القوة والضعف، ويقدم التوصيات المناسبة للتحسين المستمر.
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow-lg p-4 border-r-4 border-blue-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">إجمالي التقييمات</p>
                <p className="text-2xl font-bold text-blue-600">{totalEvaluations}</p>
              </div>
              <Target className="h-10 w-10 text-blue-500 opacity-20" />
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-4 border-r-4 border-green-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">عدد الموظفين</p>
                <p className="text-2xl font-bold text-green-600">{employeesData.length}</p>
              </div>
              <Users className="h-10 w-10 text-green-500 opacity-20" />
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-4 border-r-4 border-yellow-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">متوسط التقييم</p>
                <p className="text-2xl font-bold text-yellow-600">{averageRating.toFixed(1)}</p>
              </div>
              <Star className="h-10 w-10 text-yellow-500 opacity-20" />
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-4 border-r-4 border-purple-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">نسبة الرضا</p>
                <p className="text-2xl font-bold text-purple-600">{Math.round((averageRating / 5) * 100)}%</p>
              </div>
              <ThumbsUp className="h-10 w-10 text-purple-500 opacity-20" />
            </div>
          </div>
        </div>

        {/* Employees Table */}
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden mb-6">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4">
            <h2 className="text-xl font-bold text-white flex items-center space-x-3 space-x-reverse">
              <Users className="h-6 w-6" />
              <span>ثانياً: تحليل أداء الموظفين بناءً على الاستبيانات</span>
            </h2>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-gray-900">اسم الموظف</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-gray-900">القسم/المسمى</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-gray-900">عدد التقييمات</th>
                  <th className="px-4 py-3 text-center text-sm font-semibold text-gray-900">متوسط التقييم (/5)</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-gray-900">نقاط القوة</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-gray-900">ملاحظات سلبية</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {employeesData.map((employee, index) => (
                  <tr key={index} className="hover:bg-gray-50 transition-colors duration-150">
                    <td className="px-4 py-3">
                      <div className="flex items-center space-x-3 space-x-reverse">
                        <div className="bg-gradient-to-r from-blue-500 to-indigo-500 h-8 w-8 rounded-full flex items-center justify-center">
                          <User className="h-4 w-4 text-white" />
                        </div>
                        <div>
                          {isEditing ? (
                            <input
                              type="text"
                              value={employee.name}
                              onChange={(e) => updateEmployeeData(index, 'name', e.target.value)}
                              className="font-semibold text-gray-900 bg-transparent border-b border-gray-300 focus:outline-none focus:border-blue-500"
                            />
                          ) : (
                            <p className="font-semibold text-gray-900">{employee.name}</p>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-center">
                      {isEditing ? (
                        <input
                          type="text"
                          value={employee.position}
                          onChange={(e) => updateEmployeeData(index, 'position', e.target.value)}
                          className="text-center bg-transparent border-b border-gray-300 focus:outline-none focus:border-blue-500"
                        />
                      ) : (
                        <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-sm font-semibold">
                          {employee.position}
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-center">
                      {isEditing ? (
                        <input
                          type="number"
                          value={employee.evaluations}
                          onChange={(e) => updateEmployeeData(index, 'evaluations', parseInt(e.target.value))}
                          className="w-16 text-center bg-transparent border-b border-gray-300 focus:outline-none focus:border-blue-500"
                        />
                      ) : (
                        <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-sm font-semibold">
                          {employee.evaluations}
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <div className="flex items-center justify-center space-x-1 space-x-reverse">
                        <Star className="h-4 w-4 text-yellow-400 fill-current" />
                        {isEditing ? (
                          <input
                            type="number"
                            step="0.1"
                            min="0"
                            max="5"
                            value={employee.rating}
                            onChange={(e) => updateEmployeeData(index, 'rating', parseFloat(e.target.value))}
                            className="w-16 text-center bg-transparent border-b border-gray-300 focus:outline-none focus:border-blue-500"
                          />
                        ) : (
                          <span className="font-semibold text-gray-900">{employee.rating}</span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      {isEditing ? (
                        <textarea
                          value={employee.strengths}
                          onChange={(e) => updateEmployeeData(index, 'strengths', e.target.value)}
                          className="w-full bg-transparent border border-gray-300 rounded px-2 py-1 focus:outline-none focus:border-blue-500 text-sm"
                          rows={2}
                        />
                      ) : (
                        <p className="text-sm text-gray-600 max-w-xs">{employee.strengths}</p>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      {isEditing ? (
                        <textarea
                          value={employee.negativeNotes}
                          onChange={(e) => updateEmployeeData(index, 'negativeNotes', e.target.value)}
                          className="w-full bg-transparent border border-gray-300 rounded px-2 py-1 focus:outline-none focus:border-blue-500 text-sm"
                          rows={2}
                        />
                      ) : (
                        <p className="text-sm text-red-600 max-w-xs">{employee.negativeNotes}</p>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* General Observations */}
        <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
          <div className="flex items-center space-x-3 space-x-reverse mb-4">
            <MessageSquare className="h-6 w-6 text-blue-600" />
            <h2 className="text-xl font-bold text-gray-900">ثالثاً: أبرز الملاحظات العامة من العملاء</h2>
          </div>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-start space-x-2 space-x-reverse">
              <AlertCircle className="h-5 w-5 text-red-500 mt-0.5 flex-shrink-0" />
              <span>بعض العملاء اشتكوا من التأخير في المواعيد.</span>
            </li>
            <li className="flex items-start space-x-2 space-x-reverse">
              <Info className="h-5 w-5 text-yellow-500 mt-0.5 flex-shrink-0" />
              <span>عدد قليل من العملاء ذكروا عدم وضوح بعض الوقت للتدريب في التطبيق (ينصح بتحديث الصور التوضيحية).</span>
            </li>
            <li className="flex items-start space-x-2 space-x-reverse">
              <ThumbsUp className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
              <span>الإشادة بعدد من الموظفين على الأسلوب الراقي في التعامل والصبر أثناء التدريب.</span>
            </li>
          </ul>
        </div>

        {/* Recommendations */}
        <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
          <div className="flex items-center space-x-3 space-x-reverse mb-4">
            <TrendingUp className="h-6 w-6 text-blue-600" />
            <h2 className="text-xl font-bold text-gray-900">رابعاً: التوصيات والتحسينات المقترحة</h2>
          </div>
          <ol className="space-y-3 text-gray-700">
            <li className="flex items-start space-x-3 space-x-reverse">
              <span className="bg-blue-100 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center text-sm font-semibold flex-shrink-0">1</span>
              <span>تحسين الرد السريع في قسم خدمة العملاء، خاصة في أوقات الذروة.</span>
            </li>
            <li className="flex items-start space-x-3 space-x-reverse">
              <span className="bg-blue-100 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center text-sm font-semibold flex-shrink-0">2</span>
              <span>تنظيم ورشة عمل داخلية للمدربين لتحسين مهارات التواصل الفعّال مع المتدربين.</span>
            </li>
            <li className="flex items-start space-x-3 space-x-reverse">
              <span className="bg-blue-100 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center text-sm font-semibold flex-shrink-0">3</span>
              <span>مكافأة الموظفين المتفوقين الذين حصلوا على أعلى تقييمات هذا الشهر لتحفيز بقية الفريق.</span>
            </li>
            <li className="flex items-start space-x-3 space-x-reverse">
              <span className="bg-blue-100 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center text-sm font-semibold flex-shrink-0">4</span>
              <span>الاستمرار في جمع الملاحظات الدقيقة والعمل على تنفيذ التحديثات المطلوبة في التطبيق.</span>
            </li>
          </ol>
        </div>

        {/* Conclusion */}
        <div className="bg-white rounded-2xl shadow-xl p-6 mb-6">
          <div className="flex items-center space-x-3 space-x-reverse mb-4">
            <CheckCircle className="h-6 w-6 text-green-600" />
            <h2 className="text-xl font-bold text-gray-900">خامساً: الخلاصة</h2>
          </div>
          <p className="text-gray-700 leading-relaxed">
            يظهر من خلال نتائج هذا الأسبوع أن الأداء العام للموظفين جيد جداً، مع متوسط تقييم إجمالي بلغ {averageRating.toFixed(2)}/5. ومع ذلك، هناك بعض الجوانب التي تحتاج إلى تحسين ومتابعة مستمرة، لا سيما في سرعة الرد والتواصل الفعّال. نوصي بالاستمرار في التقييم الأسبوعي لضمان جودة الخدمات والتحسين المستمر لأداء الموظفين.
          </p>
        </div>

        {/* Signatures Section */}
        <div className="bg-white rounded-2xl shadow-xl p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Supervisor Signature */}
            <div className="text-center">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 mb-4 min-h-[120px] flex items-center justify-center">
                <div className="text-center">
                  <PenTool className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500 text-sm">توقيع المشرف</p>
                </div>
              </div>
              <div className="space-y-1">
                <p className="font-semibold text-gray-900">المشرف</p>
                <p className="text-gray-600">أ/ نايف الشهري</p>
                <div className="border-t border-gray-300 mt-4 pt-2">
                  <p className="text-sm text-gray-500">التوقيع</p>
                </div>
              </div>
            </div>

            {/* Manager Signature */}
            <div className="text-center">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 mb-4 min-h-[120px] flex items-center justify-center">
                <div className="text-center">
                  <PenTool className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500 text-sm">توقيع المدير</p>
                </div>
              </div>
              <div className="space-y-1">
                <p className="font-semibold text-gray-900">مدير مدرسة شمال جدة لتعليم القيادة</p>
                <p className="text-gray-600">أ/ جاسر فيصل العويضي</p>
                <div className="border-t border-gray-300 mt-4 pt-2">
                  <p className="text-sm text-gray-500">التوقيع</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full mx-4">
            <h3 className="text-xl font-bold text-gray-900 mb-4 text-center">تصدير التقرير</h3>
            <div className="space-y-3">
              <button
                onClick={() => handleExport('pdf')}
                className="w-full bg-red-600 hover:bg-red-700 text-white py-3 px-4 rounded-xl flex items-center justify-center space-x-3 space-x-reverse transition-all duration-200"
              >
                <FileText className="h-5 w-5" />
                <span>تصدير كـ PDF</span>
              </button>
              <button
                onClick={() => handleExport('excel')}
                className="w-full bg-green-600 hover:bg-green-700 text-white py-3 px-4 rounded-xl flex items-center justify-center space-x-3 space-x-reverse transition-all duration-200"
              >
                <BarChart3 className="h-5 w-5" />
                <span>تصدير كـ Excel</span>
              </button>
              <button
                onClick={() => handleExport('word')}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-xl flex items-center justify-center space-x-3 space-x-reverse transition-all duration-200"
              >
                <BookOpen className="h-5 w-5" />
                <span>تصدير كـ Word</span>
              </button>
            </div>
            <button
              onClick={() => setShowExportModal(false)}
              className="w-full mt-4 bg-gray-500 hover:bg-gray-600 text-white py-3 px-4 rounded-xl transition-all duration-200"
            >
              إلغاء
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;